export function Button({ children, variant = "default" }) {
  const base = "px-4 py-2 rounded font-semibold transition";
  const variants = {
    default: "bg-blue-600 text-white hover:bg-blue-700",
    outline: "border border-gray-300 text-white hover:bg-gray-800"
  };
  return <button className={\`\${base} \${variants[variant]}\`}>{children}</button>;
}